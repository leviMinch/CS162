/*********************************************************************
** Program Filename: prog.cpp
** Author: Levi Minch
** Date: May 29th, 2023
** Description: main function for the game, creates a game object and runs the game
** Input: none
** Output: none
*********************************************************************/
#include "game.h"
#include <iostream>

using namespace std;

int main(){  
    Game game;
    return 0;
}